
import nextcord
from nextcord.ext import commands
import telnetlib
import json
import asyncio
import threading
import time

# Load config
with open("config.json") as f:
    config = json.load(f)

DISCORD_TOKEN = config["DISCORD_TOKEN"]
TELNET_HOST = config["TELNET_HOST"]
TELNET_PORT = config["TELNET_PORT"]
TELNET_PASSWORD = config["TELNET_PASSWORD"]
RELAY_CHANNELS = config["RELAY_CHANNELS"]
ADMIN_ROLE_NAME = config["ADMIN_ROLE_NAME"]
GAME_CHAT_CHANNEL_ID = config["GAME_CHAT_CHANNEL_ID"]
PLAYER_NOTIF_CHANNEL_ID = config["PLAYER_NOTIF_CHANNEL_ID"]

# Discord bot
intents = nextcord.Intents.default()
intents.messages = True
intents.message_content = True
bot = commands.Bot(command_prefix="", intents=intents)

last_chat_line = None
user_last_message_time = {}

def send_telnet_command(command):
    try:
        tn = telnetlib.Telnet(TELNET_HOST, TELNET_PORT)
        tn.read_until(b"Please enter password:")
        tn.write(TELNET_PASSWORD.encode('ascii') + b"\n")
        tn.write(command.encode('ascii') + b"\n")
        tn.write(b"exit\n")
        output = tn.read_all().decode('ascii')
        return output
    except Exception as e:
        print(f"❌ Telnet error: {e}")
        return None

# Slash Commands
@bot.slash_command(name="status", description="Show server info (admin only)")
async def status(interaction: nextcord.Interaction):
    if not any(role.name == ADMIN_ROLE_NAME for role in interaction.user.roles):
        await interaction.response.send_message("❌ You don't have permission.", ephemeral=True)
        return
    await interaction.response.defer()
    info = send_telnet_command("lp") or "⚠️ Couldn't get server info."
    await interaction.followup.send(f"\n{info}\n")

@bot.slash_command(name="say", description="Send a message to 7DTD chat")
async def say(interaction: nextcord.Interaction, message: str):
    if not any(role.name == ADMIN_ROLE_NAME for role in interaction.user.roles):
        await interaction.response.send_message("❌ You don't have permission.", ephemeral=True)
        return
    send_telnet_command(f'say "[Discord] {interaction.user.display_name}: {message}"')
    await interaction.response.send_message("✅ Message sent!")

@bot.slash_command(name="restart", description="Restart the 7DTD server")
async def restart(interaction: nextcord.Interaction):
    if not any(role.name == ADMIN_ROLE_NAME for role in interaction.user.roles):
        await interaction.response.send_message("❌ You don't have permission.", ephemeral=True)
        return
    await interaction.response.send_message("⚠️ Restarting server in 10 seconds...")
    send_telnet_command("say Server restarting in 10 seconds")
    await asyncio.sleep(10)
    send_telnet_command("shutdown")
    await interaction.followup.send("✅ Server shutdown initiated.")

# Player join/leave notifications
def monitor_player_activity():
    global last_chat_line
    while True:
        try:
            tn = telnetlib.Telnet(TELNET_HOST, TELNET_PORT)
            tn.read_until(b"Please enter password:")
            tn.write(TELNET_PASSWORD.encode('ascii') + b"\n")
            tn.write(b"taillog\n")
            while True:
                line = tn.read_until(b"\n").decode('ascii').strip()
                if line and line != last_chat_line:
                    last_chat_line = line
                    if "joined the game" in line:
                        player = line.split(" joined the game")[0]
                        asyncio.run_coroutine_threadsafe(send_to_player_channel(f"✅ {player} joined the game."), bot.loop)
                    elif "left the game" in line:
                        player = line.split(" left the game")[0]
                        asyncio.run_coroutine_threadsafe(send_to_player_channel(f"❌ {player} left the game."), bot.loop)
                    # Relay player chat
                    if "Chat (from '" in line and "to 'Global'" in line:
                        if "joined the game" not in line and "left the game" not in line:
                            try:
                                start = line.index("Chat (from '") + len("Chat (from '")
                                end = line.index("'", start)
                                player = line[start:end]
                                message_start = line.index("):") + 3
                                message = line[message_start:]
                                relay_message = f"💬 [{player}]: {message}"
                                asyncio.run_coroutine_threadsafe(send_to_game_chat_channel(relay_message), bot.loop)
                            except Exception as parse_err:
                                print(f"Failed to parse chat line: {parse_err}")
        except Exception as e:
            print(f"Error monitoring player activity: {e}")
            time.sleep(5)

async def send_to_player_channel(message):
    try:
        channel = bot.get_channel(int(PLAYER_NOTIF_CHANNEL_ID))
        if channel:
            await channel.send(message)
        else:
            print(f"❌ Could not find PLAYER_NOTIF_CHANNEL_ID: {PLAYER_NOTIF_CHANNEL_ID}")
    except nextcord.errors.Forbidden:
        print(f"❌ Missing permissions to send to PLAYER_NOTIF_CHANNEL_ID: {PLAYER_NOTIF_CHANNEL_ID}")
    except Exception as e:
        print(f"❌ Error sending to PLAYER_NOTIF_CHANNEL_ID: {e}")

async def send_to_game_chat_channel(message):
    try:
        channel = bot.get_channel(int(GAME_CHAT_CHANNEL_ID))
        if channel:
            await channel.send(message)
        else:
            print(f"❌ Could not find GAME_CHAT_CHANNEL_ID: {GAME_CHAT_CHANNEL_ID}")
    except nextcord.errors.Forbidden:
        print(f"❌ Missing permissions to send to GAME_CHAT_CHANNEL_ID: {GAME_CHAT_CHANNEL_ID}")
    except Exception as e:
        print(f"❌ Error sending to GAME_CHAT_CHANNEL_ID: {e}")

async def send_to_player_channel(message):
    channel = bot.get_channel(int(PLAYER_NOTIF_CHANNEL_ID))
    if channel:
        await channel.send(message)

async def send_to_game_chat_channel(message):
    channel = bot.get_channel(int(GAME_CHAT_CHANNEL_ID))
    if channel:
        await channel.send(message)

@bot.event
async def on_message(message):
    if message.author == bot.user:
        return
    if message.channel.id == int(GAME_CHAT_CHANNEL_ID) and not message.content.startswith("/"):
        now = time.time()
        user_id = message.author.id
        last_time = user_last_message_time.get(user_id, 0)
        if now - last_time >= 2:
            user_last_message_time[user_id] = now
            author_name = message.author.display_name
            text = message.content
            send_telnet_command(f'say [Discord] {author_name}: {text}')
        else:
            print(f"Rate limited message from {message.author.display_name}")
    await bot.process_commands(message)

# Start monitoring thread
threading.Thread(target=monitor_player_activity, daemon=True).start()

@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user} (ID: {bot.user.id})")

bot.run(DISCORD_TOKEN)
